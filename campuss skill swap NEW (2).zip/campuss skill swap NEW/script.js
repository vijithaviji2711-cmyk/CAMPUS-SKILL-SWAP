document.addEventListener("DOMContentLoaded", function () {

    const searchInput = document.getElementById("skillSearch");
    const cards = document.querySelectorAll(".card");
    const resultMessage = document.getElementById("resultMessage");

    // Search skills
    searchInput.addEventListener("input", function () {
        const searchText = searchInput.value.toLowerCase().trim();
        let found = 0;

        cards.forEach(function (card) {
            if (card.textContent.toLowerCase().includes(searchText)) {
                card.style.display = "";
                found++;
            } else {
                card.style.display = "none";
            }
        });

        resultMessage.textContent = found === 0
            ? "No skills found!"
            : found + " card(s) found.";
    });

    // Click a skill card
    cards.forEach(function (card) {
        card.style.cursor = "pointer";

        card.addEventListener("click", function () {
            const skillName = card.querySelector("h3").textContent;
            resultMessage.textContent =
                "You selected: " + skillName;
        });
    });

});