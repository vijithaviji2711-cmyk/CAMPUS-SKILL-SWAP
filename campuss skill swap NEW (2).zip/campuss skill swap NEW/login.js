
document.getElementById("loginForm").addEventListener("submit", async function(event) {
    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    if (!email || !password) {
        alert("Please enter email and password.");
        return;
    }

    try {
        const response = await fetch("http://localhost:8080/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                email: email,
                password: password
            })
        });

        const result = await response.json();

        if (!response.ok) {
            alert(result.error || "Login failed. Please check your details.");
            return;
        }

        if (result.message === "Login successful!") {
            alert("Login successful!");

            // Save the logged-in student's ID
            sessionStorage.setItem("studentId", result.studentId);

            window.location.href = "dashboard.html";
        } else {
            alert(result.message || "Login failed.");
        }

    } catch (error) {
        console.error("Login error:", error);
        alert("Backend connection failed. Please check the backend server and browser console.");
    }
});
