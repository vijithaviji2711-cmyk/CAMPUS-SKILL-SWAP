
const skillForm = document.getElementById("skillForm");
const skillList = document.getElementById("skillList");
const filterButtons = document.querySelectorAll(".filter-btn");
const statusMessage = document.getElementById("statusMessage");

let skills = [
    {
        id: 1,
        name: "Java Programming",
        category: "Programming",
        type: "Teach",
        description: "Learn Java basics, OOP concepts and coding practice."
    },
    {
        id: 2,
        name: "Web Development",
        category: "Web Development",
        type: "Learn",
        description: "Practise HTML, CSS and JavaScript by building websites."
    },
    {
        id: 3,
        name: "Python Programming",
        category: "Programming",
        type: "Teach",
        description: "Explore Python fundamentals and problem solving."
    }
];

let currentFilter = "All";

const categoryIcons = {
    "Programming": "💻",
    "Web Development": "🌐",
    "Design": "🎨",
    "Communication": "🗣️",
    "Other": "📚"
};

function renderSkills() {
    skillList.replaceChildren();

    const filteredSkills = skills.filter(skill => {
        return currentFilter === "All" ||
               skill.type === currentFilter;
    });

    if (filteredSkills.length === 0) {
        const empty = document.createElement("div");
        empty.className = "empty-state";
        empty.textContent = "No skills found in this category yet.";
        skillList.appendChild(empty);
        return;
    }

    filteredSkills.forEach(skill => {
        const card = document.createElement("article");
        card.className = "skill-card";

        const icon = document.createElement("div");
        icon.className = "skill-icon";
        icon.textContent = categoryIcons[skill.category] || "📚";

        const category = document.createElement("span");
        category.className = "category";
        category.textContent = skill.category;

        const type = document.createElement("span");
        type.className = "skill-type";
        type.textContent = skill.type === "Teach"
            ? "Offering to teach"
            : "Looking to learn";

        const title = document.createElement("h3");
        title.textContent = skill.name;

        const description = document.createElement("p");
        description.textContent = skill.description ||
            "No description provided.";

        const deleteButton = document.createElement("button");
        deleteButton.type = "button";
        deleteButton.className = "delete-btn";
        deleteButton.textContent = "Remove from preview";

        deleteButton.addEventListener("click", () => {
            skills = skills.filter(item => item.id !== skill.id);
            renderSkills();
            showStatus("Skill removed from this preview.");
        });

        card.append(icon, category, document.createElement("br"),
                    type, title, description, deleteButton);

        skillList.appendChild(card);
    });
}

function showStatus(message) {
    statusMessage.textContent = message;
}

skillForm.addEventListener("submit", event => {
    event.preventDefault();

    const name = document.getElementById("skillName").value.trim();
    const category = document.getElementById("skillCategory").value;
    const type = document.getElementById("skillType").value;
    const description = document.getElementById("skillDescription").value.trim();

    if (!name || !category || !type) {
        showStatus("Please complete all required fields.");
        return;
    }

    skills.unshift({
        id: Date.now(),
        name,
        category,
        type,
        description
    });

    currentFilter = "All";

    filterButtons.forEach(button => {
        button.classList.toggle(
            "active",
            button.dataset.filter === "All"
        );
    });

    renderSkills();
    skillForm.reset();
    showStatus("Skill added to the preview successfully.");
});

filterButtons.forEach(button => {
    button.addEventListener("click", () => {
        currentFilter = button.dataset.filter;

        filterButtons.forEach(item => {
            item.classList.toggle("active", item === button);
        });

        renderSkills();
    });
});

renderSkills();
