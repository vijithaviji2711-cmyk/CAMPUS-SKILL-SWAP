
const profileForm = document.getElementById("profileForm");
const statusMessage = document.getElementById("statusMessage");

const fields = {
    fullName: document.getElementById("fullName"),
    email: document.getElementById("email"),
    department: document.getElementById("department"),
    year: document.getElementById("year"),
    bio: document.getElementById("bio"),
    mySkills: document.getElementById("mySkills")
};

function updateProfileCard() {
    const name = fields.fullName.value.trim() || "Student Name";
    const email = fields.email.value.trim() || "student@example.com";

    document.getElementById("displayName").textContent = name;
    document.getElementById("displayEmail").textContent = email;
    document.getElementById("avatar").textContent =
        name.charAt(0).toUpperCase();

    const skills = fields.mySkills.value
        .split(",")
        .map(skill => skill.trim())
        .filter(Boolean);

    document.getElementById("skillCount").textContent = skills.length;
}

function loadProfile() {
    const savedProfile = localStorage.getItem("campusSkillSwapProfile");

    if (!savedProfile) {
        return;
    }

    try {
        const profile = JSON.parse(savedProfile);

        Object.keys(fields).forEach(key => {
            if (profile[key] !== undefined) {
                fields[key].value = profile[key];
            }
        });
    } catch (error) {
        console.error("Unable to load profile:", error);
    }

    updateProfileCard();
}

profileForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const profile = {};

    Object.keys(fields).forEach(key => {
        profile[key] = fields[key].value.trim();
    });

    localStorage.setItem(
        "campusSkillSwapProfile",
        JSON.stringify(profile)
    );

    updateProfileCard();

    statusMessage.textContent = "Profile saved successfully!";
});

loadProfile();

Object.values(fields).forEach(field => {
    field.addEventListener("input", updateProfileCard);
    field.addEventListener("change", updateProfileCard);
});

