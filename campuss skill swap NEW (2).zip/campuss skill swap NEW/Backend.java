
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Backend {

    private static final int PORT = 8080;

    // Change these to match your MySQL setup.
    private static final String DB_URL =
            "jdbc:mysql://localhost:3306/campus_skill_swap";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "YOUR_MYSQL_PASSWORD";

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    private static void send(HttpExchange ex, int status, String body)
            throws IOException {
        ex.getResponseHeaders().set("Content-Type",
                "application/json; charset=UTF-8");
        ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        ex.getResponseHeaders().set("Access-Control-Allow-Headers",
                "Content-Type");
        ex.getResponseHeaders().set("Access-Control-Allow-Methods",
                "GET, POST, OPTIONS");

        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream out = ex.getResponseBody()) {
            out.write(bytes);
        }
    }

    private static String json(String value) {
        if (value == null) return "null";
        return "\"" + value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t") + "\"";
    }

    // Reads simple JSON string/number fields from frontend requests.
    private static Map<String, String> readBody(HttpExchange ex)
            throws IOException {
        String body = new String(
                ex.getRequestBody().readAllBytes(),
                StandardCharsets.UTF_8);

        Map<String, String> data = new HashMap<>();
        Pattern pattern = Pattern.compile(
                "\"([^\"]+)\"\\s*:\\s*(\"((?:\\\\.|[^\"])*)\"|null|\\d+|true|false)");

        Matcher matcher = pattern.matcher(body);
        while (matcher.find()) {
            String value = matcher.group(3);

            if (value == null) {
                value = matcher.group(2);
                if ("null".equals(value)) value = "";
            } else {
                value = value.replace("\\\"", "\"")
                             .replace("\\n", "\n")
                             .replace("\\r", "\r")
                             .replace("\\\\", "\\");
            }

            data.put(matcher.group(1), value);
        }

        return data;
    }

    private static String field(Map<String, String> data, String name) {
        return data.getOrDefault(name, "").trim();
    }

    private static int intField(Map<String, String> data, String name) {
        try {
            return Integer.parseInt(field(data, name));
        } catch (Exception e) {
            return 0;
        }
    }

    private static void execute(String sql) throws SQLException {
        try (Connection con = getConnection();
             Statement st = con.createStatement()) {
            st.executeUpdate(sql);
        }
    }

    private static void initializeDatabase() throws SQLException {
        execute("""
            CREATE TABLE IF NOT EXISTS css_students (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(190) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                department VARCHAR(100) DEFAULT '',
                study_year VARCHAR(30) DEFAULT '',
                bio TEXT,
                my_skills TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """);

        execute("""
            CREATE TABLE IF NOT EXISTS css_skills (
                id INT PRIMARY KEY AUTO_INCREMENT,
                student_id INT NOT NULL,
                skill_name VARCHAR(150) NOT NULL,
                category VARCHAR(100) DEFAULT '',
                skill_type VARCHAR(20) NOT NULL,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (student_id) REFERENCES css_students(id)
            )
            """);

        execute("""
            CREATE TABLE IF NOT EXISTS css_requests (
                id INT PRIMARY KEY AUTO_INCREMENT,
                sender_id INT NOT NULL,
                receiver_id INT NOT NULL,
                skill_id INT NOT NULL,
                message TEXT,
                status VARCHAR(20) NOT NULL DEFAULT 'Pending',
                meet_link TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (sender_id) REFERENCES css_students(id),
                FOREIGN KEY (receiver_id) REFERENCES css_students(id),
                FOREIGN KEY (skill_id) REFERENCES css_skills(id)
            )
            """);

        execute("""
            CREATE TABLE IF NOT EXISTS css_messages (
                id INT PRIMARY KEY AUTO_INCREMENT,
                request_id INT NOT NULL,
                sender_id INT NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (request_id) REFERENCES css_requests(id),
                FOREIGN KEY (sender_id) REFERENCES css_students(id)
            )
            """);

        System.out.println("Database tables ready.");
    }

    private static void register(HttpExchange ex) throws Exception {
        Map<String, String> d = readBody(ex);
        String name = field(d, "name");
        String email = field(d, "email").toLowerCase();
        String password = field(d, "password");

        if (name.isEmpty() || email.isEmpty() || password.length() < 8) {
            send(ex, 400, """
                {"success":false,"message":"Enter name, email and a password of at least 8 characters"}
                """);
            return;
        }

        // PBKDF2 password hashing is recommended for production.
        // This prototype stores a SHA-256 digest, not the plain password.
        String hash = passwordHash(password);

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(
                "INSERT INTO css_students(name,email,password_hash) VALUES(?,?,?)",
                Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, hash);
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                send(ex, 201, "{\"success\":true,\"studentId\":"
                        + keys.getInt(1) + ",\"message\":\"Registration successful\"}");
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            send(ex, 409,
                    "{\"success\":false,\"message\":\"Email already registered\"}");
        }
    }

    private static String passwordHash(String password) throws Exception {
        java.security.MessageDigest md =
                java.security.MessageDigest.getInstance("SHA-256");
        byte[] bytes = md.digest(password.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(bytes);
    }

    private static void login(HttpExchange ex) throws Exception {
        Map<String, String> d = readBody(ex);
        String email = field(d, "email").toLowerCase();
        String password = field(d, "password");

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(
                "SELECT id,name,email,password_hash FROM css_students WHERE email=?")) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() &&
                    rs.getString("password_hash").equals(passwordHash(password))) {
                    send(ex, 200, "{\"success\":true,\"studentId\":"
                            + rs.getInt("id") + ",\"name\":"
                            + json(rs.getString("name")) + ",\"email\":"
                            + json(rs.getString("email")) + "}");
                } else {
                    send(ex, 401,
                            "{\"success\":false,\"message\":\"Invalid email or password\"}");
                }
            }
        }
    }

    private static void addSkill(HttpExchange ex) throws Exception {
        Map<String, String> d = readBody(ex);
        int studentId = intField(d, "studentId");

        if (studentId <= 0 || field(d, "skillName").isEmpty()) {
            send(ex, 400, "{\"success\":false,\"message\":\"Student and skill required\"}");
            return;
        }

        String type = field(d, "skillType");
        if (!type.equalsIgnoreCase("Teach") &&
            !type.equalsIgnoreCase("Learn")) {
            send(ex, 400, "{\"success\":false,\"message\":\"Type must be Teach or Learn\"}");
            return;
        }

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("""
                INSERT INTO css_skills(student_id,skill_name,category,skill_type,description)
                SELECT id,?,?,?,? FROM css_students WHERE id=?
                """)) {
            ps.setString(1, field(d, "skillName"));
            ps.setString(2, field(d, "category"));
            ps.setString(3, type);
            ps.setString(4, field(d, "description"));
            ps.setInt(5, studentId);

            if (ps.executeUpdate() == 0) {
                send(ex, 404, "{\"success\":false,\"message\":\"Student not found\"}");
                return;
            }
            send(ex, 201, "{\"success\":true,\"message\":\"Skill added\"}");
        }
    }

    private static void allSkills(HttpExchange ex) throws Exception {
        StringBuilder out = new StringBuilder("{\"success\":true,\"skills\":[");
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("""
                SELECT s.id,s.student_id,s.skill_name,s.category,
                       s.skill_type,s.description,u.name AS student_name
                FROM css_skills s
                JOIN css_students u ON u.id=s.student_id
                ORDER BY s.id DESC
                """);
             ResultSet rs = ps.executeQuery()) {

            boolean first = true;
            while (rs.next()) {
                if (!first) out.append(",");
                first = false;
                out.append("{\"id\":").append(rs.getInt("id"))
                   .append(",\"studentId\":").append(rs.getInt("student_id"))
                   .append(",\"skillName\":").append(json(rs.getString("skill_name")))
                   .append(",\"category\":").append(json(rs.getString("category")))
                   .append(",\"skillType\":").append(json(rs.getString("skill_type")))
                   .append(",\"description\":").append(json(rs.getString("description")))
                   .append(",\"studentName\":").append(json(rs.getString("student_name")))
                   .append("}");
            }
        }
        out.append("]}");
        send(ex, 200, out.toString());
    }

    private static void sendRequest(HttpExchange ex) throws Exception {
        Map<String, String> d = readBody(ex);
        int sender = intField(d, "senderId");
        int skill = intField(d, "skillId");

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("""
                INSERT INTO css_requests(sender_id,receiver_id,skill_id,message)
                SELECT ?,student_id,id,? FROM css_skills
                WHERE id=? AND student_id<>?
                """)) {

            ps.setInt(1, sender);
            ps.setString(2, field(d, "message"));
            ps.setInt(3, skill);
            ps.setInt(4, sender);

            if (ps.executeUpdate() == 0) {
                send(ex, 400,
                    "{\"success\":false,\"message\":\"Invalid skill or cannot request your own skill\"}");
                return;
            }
            send(ex, 201, "{\"success\":true,\"message\":\"Request sent\"}");
        }
    }

    private static void respondRequest(HttpExchange ex) throws Exception {
        Map<String, String> d = readBody(ex);
        int requestId = intField(d, "requestId");
        int receiverId = intField(d, "studentId");
        String status = field(d, "status");

        if (!status.equalsIgnoreCase("Accepted") &&
            !status.equalsIgnoreCase("Rejected")) {
            send(ex, 400, "{\"success\":false,\"message\":\"Status must be Accepted or Rejected\"}");
            return;
        }

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("""
                UPDATE css_requests SET status=?
                WHERE id=? AND receiver_id=? AND status='Pending'
                """)) {

            ps.setString(1, status);
            ps.setInt(2, requestId);
            ps.setInt(3, receiverId);

            if (ps.executeUpdate() == 0) {
                send(ex, 403, "{\"success\":false,\"message\":\"Request not found or not permitted\"}");
                return;
            }
            send(ex, 200, "{\"success\":true,\"status\":" + json(status) + "}");
        }
    }

    private static void requests(HttpExchange ex) throws Exception {
        Map<String, String> d = readBody(ex);
        int studentId = intField(d, "studentId");

        StringBuilder out = new StringBuilder("{\"success\":true,\"requests\":[");
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("""
                SELECT r.id,r.sender_id,r.receiver_id,r.skill_id,r.message,
                       r.status,r.meet_link,s.skill_name,
                       a.name AS sender_name,b.name AS receiver_name
                FROM css_requests r
                JOIN css_skills s ON s.id=r.skill_id
                JOIN css_students a ON a.id=r.sender_id
                JOIN css_students b ON b.id=r.receiver_id
                WHERE r.sender_id=? OR r.receiver_id=?
                ORDER BY r.id DESC
                """)) {

            ps.setInt(1, studentId);
            ps.setInt(2, studentId);

            try (ResultSet rs = ps.executeQuery()) {
                boolean first = true;
                while (rs.next()) {
                    if (!first) out.append(",");
                    first = false;
                    out.append("{\"requestId\":").append(rs.getInt("id"))
                       .append(",\"senderId\":").append(rs.getInt("sender_id"))
                       .append(",\"receiverId\":").append(rs.getInt("receiver_id"))
                       .append(",\"skillId\":").append(rs.getInt("skill_id"))
                       .append(",\"skillName\":").append(json(rs.getString("skill_name")))
                       .append(",\"senderName\":").append(json(rs.getString("sender_name")))
                       .append(",\"receiverName\":").append(json(rs.getString("receiver_name")))
                       .append(",\"message\":").append(json(rs.getString("message")))
                       .append(",\"status\":").append(json(rs.getString("status")))
                       .append(",\"meetLink\":").append(json(rs.getString("meet_link")))
                       .append("}");
                }
            }
        }
        out.append("]}");
        send(ex, 200, out.toString());
    }

    private static void sendMessage(HttpExchange ex) throws Exception {
        Map<String, String> d = readBody(ex);
        int requestId = intField(d, "requestId");
        int senderId = intField(d, "senderId");
        String message = field(d, "message");
        String meetLink = field(d, "meetLink");

        if (message.isEmpty() && meetLink.isEmpty()) {
            send(ex, 400, "{\"success\":false,\"message\":\"Message or Meet link required\"}");
            return;
        }

        if (!meetLink.isEmpty() &&
            !(meetLink.startsWith("https://meet.google.com/"))) {
            send(ex, 400, "{\"success\":false,\"message\":\"Enter a valid Google Meet link\"}");
            return;
        }

        try (Connection con = getConnection()) {
            con.setAutoCommit(false);
            try {
                try (PreparedStatement check = con.prepareStatement("""
                    SELECT id FROM css_requests
                    WHERE id=? AND status='Accepted'
                    AND (sender_id=? OR receiver_id=?)
                    """)) {
                    check.setInt(1, requestId);
                    check.setInt(2, senderId);
                    check.setInt(3, senderId);
                    try (ResultSet rs = check.executeQuery()) {
                        if (!rs.next()) {
                            con.rollback();
                            send(ex, 403, "{\"success\":false,\"message\":\"Accepted request required\"}");
                            return;
                        }
                    }
                }

                if (!message.isEmpty()) {
                    try (PreparedStatement ps = con.prepareStatement(
                            "INSERT INTO css_messages(request_id,sender_id,message) VALUES(?,?,?)")) {
                        ps.setInt(1, requestId);
                        ps.setInt(2, senderId);
                        ps.setString(3, message);
                        ps.executeUpdate();
                    }
                }

                if (!meetLink.isEmpty()) {
                    try (PreparedStatement ps = con.prepareStatement(
                            "UPDATE css_requests SET meet_link=? WHERE id=?")) {
                        ps.setString(1, meetLink);
                        ps.setInt(2, requestId);
                        ps.executeUpdate();
                    }
                }

                con.commit();
                send(ex, 201, "{\"success\":true,\"message\":\"Sent\"}");
            } catch (Exception e) {
                con.rollback();
                throw e;
            }
        }
    }

    private static void chatMessages(HttpExchange ex) throws Exception {
        Map<String, String> d = readBody(ex);
        int requestId = intField(d, "requestId");
        int studentId = intField(d, "studentId");

        StringBuilder out = new StringBuilder("{\"success\":true,\"messages\":[");
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("""
                SELECT m.id,m.sender_id,m.message,m.created_at
                FROM css_messages m
                JOIN css_requests r ON r.id=m.request_id
                WHERE m.request_id=? AND r.status='Accepted'
                AND (r.sender_id=? OR r.receiver_id=?)
                ORDER BY m.id
                """)) {
            ps.setInt(1, requestId);
            ps.setInt(2, studentId);
            ps.setInt(3, studentId);

            try (ResultSet rs = ps.executeQuery()) {
                boolean first = true;
                while (rs.next()) {
                    if (!first) out.append(",");
                    first = false;
                    out.append("{\"id\":").append(rs.getInt("id"))
                       .append(",\"senderId\":").append(rs.getInt("sender_id"))
                       .append(",\"message\":").append(json(rs.getString("message")))
                       .append(",\"createdAt\":").append(json(rs.getString("created_at")))
                       .append("}");
                }
            }
        }
        out.append("]}");
        send(ex, 200, out.toString());
    }

    private static void profile(HttpExchange ex) throws Exception {
        Map<String, String> d = readBody(ex);
        int id = intField(d, "studentId");

        if ("GET".equalsIgnoreCase(ex.getRequestMethod())) {
            try (Connection con = getConnection();
                 PreparedStatement ps = con.prepareStatement("""
                    SELECT id,name,email,department,study_year,bio,my_skills
                    FROM css_students WHERE id=?
                    """)) {
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        send(ex, 404, "{\"success\":false,\"message\":\"Profile not found\"}");
                        return;
                    }
                    send(ex, 200, "{\"success\":true,\"studentId\":" + rs.getInt("id")
                        + ",\"name\":" + json(rs.getString("name"))
                        + ",\"email\":" + json(rs.getString("email"))
                        + ",\"department\":" + json(rs.getString("department"))
                        + ",\"year\":" + json(rs.getString("study_year"))
                        + ",\"bio\":" + json(rs.getString("bio"))
                        + ",\"mySkills\":" + json(rs.getString("my_skills")) + "}");
                }
            }
            return;
        }

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("""
                UPDATE css_students
                SET name=?,department=?,study_year=?,bio=?,my_skills=?
                WHERE id=?
                """)) {
            ps.setString(1, field(d, "name"));
            ps.setString(2, field(d, "department"));
            ps.setString(3, field(d, "year"));
            ps.setString(4, field(d, "bio"));
            ps.setString(5, field(d, "mySkills"));
            ps.setInt(6, id);

            if (ps.executeUpdate() == 0) {
                send(ex, 404, "{\"success\":false,\"message\":\"Profile not found\"}");
                return;
            }
            send(ex, 200, "{\"success\":true,\"message\":\"Profile saved\"}");
        }
    }

    private static void handle(HttpExchange ex) throws IOException {
        String path = ex.getRequestURI().getPath();
        String method = ex.getRequestMethod();

        if ("OPTIONS".equalsIgnoreCase(method)) {
            send(ex, 204, "");
            return;
        }

        try {
            switch (path) {
                case "/register" -> register(ex);
                case "/login" -> login(ex);
                case "/add-skill" -> addSkill(ex);
                case "/all-skills", "/skills" -> allSkills(ex);
                case "/send-request" -> sendRequest(ex);
                case "/respond-request" -> respondRequest(ex);
                case "/my-requests" -> requests(ex);
                case "/send-message" -> sendMessage(ex);
                case "/chat-messages" -> chatMessages(ex);
                case "/profile" -> profile(ex);
                default -> send(ex, 404,
                        "{\"success\":false,\"message\":\"API route not found\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            try {
                send(ex, 500,
                    "{\"success\":false,\"message\":\"Server error; check Java console\"}");
            } catch (IOException ignored) {}
        } finally {
            ex.close();
        }
    }

    public static void main(String[] args) throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        initializeDatabase();

        HttpServer server = HttpServer.create(
                new InetSocketAddress(PORT), 0);

        server.createContext("/", Backend::handle);
        server.setExecutor(java.util.concurrent.Executors.newFixedThreadPool(10));
        server.start();

        System.out.println("Campus Skill Swap backend running at http://localhost:" + PORT);
        System.out.println("Keep this terminal open while using the website.");
    }
}
