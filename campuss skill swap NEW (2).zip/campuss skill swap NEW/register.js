
const form = document.getElementById("registerForm");
const message = document.getElementById("message");

form.addEventListener("submit", async function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const department = document.getElementById("department").value;
    const year = document.getElementById("year").value;

    if (!name || !email || password.length < 6 || !department || !year) {
        message.textContent = "Please fill all fields correctly.";
        message.style.color = "red";
        return;
    }

    try {
        const response = await fetch("http://localhost:8080/register", {
            method: "POST",
            headers: {
                "Content-Type": "text/plain"
            },
            body: JSON.stringify({
                name: name,
                email: email,
                password: password,
                department: department,
                year: year
            })
        });

        const result = await response.text();

if (response.ok) {
    message.textContent = result;
    message.style.color = "green";
} else {
    message.textContent = result;
    message.style.color = "red";
}
    } catch (error) {
        message.textContent = "Cannot connect to backend!";
        message.style.color = "red";
    }
});
