
const messages = document.getElementById("messages");
const chatForm = document.getElementById("chatForm");
const messageInput = document.getElementById("messageInput");
const doubtButton = document.getElementById("doubtButton");
const resourceForm = document.getElementById("resourceForm");

function addMessage(text, type = "message") {
    const welcome = messages.querySelector(".welcome");
    if (welcome) {
        welcome.remove();
    }

    const bubble = document.createElement("div");
    bubble.className = type;
    bubble.textContent = text;

    if (type === "message") {
        const time = document.createElement("small");
        time.textContent = new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit"
        });
        bubble.appendChild(time);
    }

    messages.appendChild(bubble);
    messages.scrollTop = messages.scrollHeight;
}

chatForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const text = messageInput.value.trim();
    if (!text) return;

    addMessage(text);
    messageInput.value = "";
    messageInput.focus();
});

doubtButton.addEventListener("click", function () {
    messageInput.value = "Doubt: ";
    messageInput.focus();
});

resourceForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const title = document.getElementById("resourceTitle").value.trim();
    const link = document.getElementById("resourceLink").value.trim();

    try {
        const url = new URL(link);

        if (url.protocol !== "https:" && url.protocol !== "http:") {
            alert("Please enter a valid HTTP or HTTPS link.");
            return;
        }

        addMessage("📒 Shared resource: " + title + "\n" + url.href);
        resourceForm.reset();
    } catch {
        alert("Please enter a valid website link.");
    }
});
