
const incomingList = document.getElementById("incomingList");
const sentList = document.getElementById("sentList");
const requestForm = document.getElementById("requestForm");
const formStatus = document.getElementById("formStatus");

let incomingRequests = [
    {
        id: 1,
        name: "Arun Kumar",
        skill: "Java Programming",
        message: "I want to learn Java OOP concepts and practise coding.",
        status: "Pending"
    },
    {
        id: 2,
        name: "Priya S",
        skill: "Web Development",
        message: "Can you help me understand HTML and CSS basics?",
        status: "Pending"
    }
];

let sentRequests = [
    {
        id: 3,
        name: "Rahul M",
        skill: "Python Programming",
        message: "I want to learn Python fundamentals.",
        status: "Pending"
    }
];

let nextId = 4;

function createElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
}

function createStatus(status) {
    const tag = createElement(
        "span",
        "status-tag " + status.toLowerCase(),
        status
    );
    return tag;
}

function renderIncoming() {
    incomingList.replaceChildren();

    if (incomingRequests.length === 0) {
        incomingList.appendChild(
            createElement("div", "empty-state", "No incoming requests right now.")
        );
        return;
    }

    incomingRequests.forEach(request => {
        const card = createElement("article", "request-card");
        const info = createElement("div", "request-info");

        info.appendChild(createElement("h3", "", request.name));
        info.appendChild(createElement("span", "skill-tag", request.skill));
        info.appendChild(createElement("p", "", request.message));
        info.appendChild(createStatus(request.status));

        card.appendChild(info);

        if (request.status === "Pending") {
            const actions = createElement("div", "actions");

            const accept = createElement("button", "accept-btn", "Accept");
            accept.type = "button";
            accept.addEventListener("click", () => {
                request.status = "Accepted";
                renderAll();
            });

            const reject = createElement("button", "reject-btn", "Reject");
            reject.type = "button";
            reject.addEventListener("click", () => {
                request.status = "Rejected";
                renderAll();
            });

            actions.append(accept, reject);
            card.appendChild(actions);
        }

        incomingList.appendChild(card);
    });
}

function renderSent() {
    sentList.replaceChildren();

    if (sentRequests.length === 0) {
        sentList.appendChild(
            createElement("div", "empty-state", "You have not sent any requests yet.")
        );
        return;
    }

    sentRequests.forEach(request => {
        const card = createElement("article", "request-card");
        const info = createElement("div", "request-info");

        info.appendChild(createElement("h3", "", request.name));
        info.appendChild(createElement("span", "skill-tag", request.skill));
        info.appendChild(createElement("p", "", request.message));
        info.appendChild(createStatus(request.status));

        card.appendChild(info);
        sentList.appendChild(card);
    });
}

function renderStats() {
    document.getElementById("incomingCount").textContent =
        incomingRequests.filter(request => request.status === "Pending").length;

    document.getElementById("sentCount").textContent = sentRequests.length;

    document.getElementById("acceptedCount").textContent =
        incomingRequests.filter(request => request.status === "Accepted").length +
        sentRequests.filter(request => request.status === "Accepted").length;
}

function renderAll() {
    renderIncoming();
    renderSent();
    renderStats();
}

requestForm.addEventListener("submit", event => {
    event.preventDefault();

    const name = document.getElementById("studentName").value.trim();
    const skill = document.getElementById("skillName").value.trim();
    const message = document.getElementById("requestMessage").value.trim();

    if (!name || !skill) {
        formStatus.textContent = "Please enter the student name and skill.";
        return;
    }

    sentRequests.unshift({
        id: nextId++,
        name,
        skill,
        message: message || "I would like to learn this skill from you.",
        status: "Pending"
    });

    renderAll();
    requestForm.reset();
    formStatus.textContent = "Request added to the preview successfully.";
});

renderAll();
